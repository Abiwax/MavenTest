﻿using System;
using System.Web.UI.WebControls;
using RestSharp;
using RestSharp.Deserializers;
using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace Student.style
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LabelUser.Text = "Welcome ";
            
            //1st JSON API
            var client = new RestClient("http://140.184.183.17:8080/RestTut/rest/details");
            var request = new RestRequest(Method.GET);
            IRestResponse response = client.Execute(request);
            
            RestSharp.Deserializers.JsonDeserializer deserial = new JsonDeserializer();
            var JSONObj = deserial.Deserialize<Dictionary<string, string>>(response);
            var details = JSONObj["details"];
            var jsonConvert = new JavaScriptSerializer();
            List<Details> detailsList = jsonConvert.Deserialize<List<Details>>(details);
            //loop through list
            foreach (var detail in detailsList)
            {
                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();
                TableCell cell4 = new TableCell();
                cell1.Text = detail.firstName;
                cell2.Text = detail.lastName;
                cell3.Text = detail.age;
                cell4.Text = detail.score;
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                row.Cells.Add(cell4);
                table1.Rows.Add(row);
            }

            //2nd REST API
            var client2 = new RestClient("http://140.184.183.17:8080/RestTutSpring/rest/details");
            var request2 = new RestRequest(Method.GET);
            IRestResponse response2 = client2.Execute(request2);
            List<Details> detailList = deserial.Deserialize<List<Details>>(response2);
            
            foreach(var detail in detailList)
            {
                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();
                TableCell cell4 = new TableCell();
                cell1.Text = detail.firstName;
                cell2.Text = detail.lastName;
                cell3.Text = detail.age;
                cell4.Text = detail.score;
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                row.Cells.Add(cell4);
                table2.Rows.Add(row);
            }
            

        }


        protected void Register_User1(object sender, EventArgs e)
        {
            string firstName = FirstName1.Text;
            string lastName = LastName1.Text;
            string age = Age1.Text;
            string score = Score1.Text;
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(age) || string.IsNullOrEmpty(score))
            {
                Error1.Text = "One or more fields were not inserted";
            }
            else
            {
                var client = new RestClient("http://140.184.183.17:8080/RestTut/rest/insert");
                var request = new RestRequest(Method.POST);
                var xmlObject = "<details><age>" + age + "</age><firstName>" + firstName + "</firstName><lastName>" + lastName + "</lastName><score>" + score + "</score></details>";
                request.AddParameter("application/xml", xmlObject, ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                if (response.Content.Length != 0)
                {
                    LabelError.Text = "Data Inserted";
                }
                else
                {
                    LabelError.Text = "Data not Inserted";
                }
            }
        }


        protected void Register_User2(object sender, EventArgs e)
        {
            string firstName = FirstName2.Text;
            string lastName = LastName2.Text;
            string age = Age2.Text;
            string score = Score2.Text;
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(age) || string.IsNullOrEmpty(score))
            {
                Error2.Text = "One or more fields were not inserted";
            }
            else
            {
                var client = new RestClient("http://140.184.183.17:8080/RestTutSpring/rest/insert");
                var request = new RestRequest();
                request.Method = Method.POST;
                // request.AddHeader("cache-control", "no-cache");
                //request.Parameters.Clear();
                //request.AddHeader("content-type", "application/json");
                //x-www-form-urlencoded
                var jsonObject = "{\n\"firstname\":\"" + firstName + "\",\n\"lastname\":\"" + lastName + "\",\n\"score\":\"" + score + "\",\n\"age\":\"" + age + "\"\n}";
                request.AddParameter("application/json", jsonObject , ParameterType.RequestBody);
                
                IRestResponse response = client.Execute(request);
                if (response.Content.Length != 0)
                    {
                    LabelError.Text = "Data Inserted";
                    }
                    else
                    {
                    LabelError.Text = "Data not Inserted";
                    }
            }
        }
    }
}